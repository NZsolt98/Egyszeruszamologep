﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PL1
{
    
    public partial class Form1 : Form
    {
        public string text;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            text = text + "1";
            textBox1.Text = text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            text = text + "2";
            textBox1.Text = text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            text = text + "3";
            textBox1.Text = text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            text = text + "4";
            textBox1.Text = text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            text = text + "5";
            textBox1.Text = text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            text = text + "6";
            textBox1.Text = text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            text = text + "7";
            textBox1.Text = text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            text = text + "8";
            textBox1.Text = text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            text = text + "9";
            textBox1.Text = text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            text = text + "0";
            textBox1.Text = text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            text = text.Remove(text.Length-1, 1);
            textBox1.Text = text;
        }
    }
}
